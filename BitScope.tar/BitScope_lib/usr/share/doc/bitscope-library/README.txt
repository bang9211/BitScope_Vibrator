 ---------------------------------------------------------------------

                    BITLIB - BITSCOPE LIBRARY

                     Version 2.0 Build FE26B

             http://bitscope.com/software/library/

    Copyright (C) 2015 by BitScope Designs. All Rights Reserved.

 ---------------------------------------------------------------------
